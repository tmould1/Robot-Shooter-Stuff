package org.usfirst.frc.team4209.robot.subsystems;
//import org.usfirst.frc.team4209.robot.Robot;

import edu.wpi.first.wpilibj.command.Subsystem;

//import org.usfirst.frc.team4209.robot.OI;

public class DriveTrain extends Subsystem {
	private static DriveTrain instance = new DriveTrain();
	
	public static DriveTrain getInstance() {
		return instance;
	}
	private DriveTrain() { }
	
	public void initDefaultCommand() {
	}
	public void drive() {
		
	}
	public void driveAuto() {
			
		}
		/**
		 * Drive the robot with the specified parameters.
		 * @param mag the magnitude of motion[-1,1]
		 * @param dir the Driection of motion (degrees)
		 * @param rot rotation to apply [-1,1]
		 */
		public void stop() {
			
		}
	}
	